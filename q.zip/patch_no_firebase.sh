#!/bin/bash
# Патч для отключения Firebase и интернет-разрешения из проекта Happ Decryptor

echo "=== Патчим build.gradle.kts ==="
sed -i 's/alias(libs.plugins.google.services)/\/\/ alias(libs.plugins.google.services)/' app/build.gradle.kts
sed -i 's/alias(libs.plugins.google.devtools.ksp)/\/\/ alias(libs.plugins.google.devtools.ksp)/' app/build.gradle.kts
sed -i 's/implementation(platform(libs.firebase.bom))/\/\/ implementation(platform(libs.firebase.bom))/' app/build.gradle.kts
sed -i 's/implementation(libs.firebase.ai)/\/\/ implementation(libs.firebase.ai)/' app/build.gradle.kts
sed -i 's/implementation(libs.firebase.appcheck.recaptcha)/\/\/ implementation(libs.firebase.appcheck.recaptcha)/' app/build.gradle.kts
sed -i 's/"ksp"(libs.androidx.room.compiler)/\/\/ "ksp"(libs.androidx.room.compiler)/' app/build.gradle.kts
sed -i 's/"ksp"(libs.moshi.kotlin.codegen)/\/\/ "ksp"(libs.moshi.kotlin.codegen)/' app/build.gradle.kts

echo "=== Патчим AndroidManifest.xml ==="
sed -i 's/<uses-permission android:name="android.permission.INTERNET" \/>/<!-- <uses-permission android:name="android.permission.INTERNET" \/> -->/' app/src/main/AndroidManifest.xml

echo "=== Готово ==="
