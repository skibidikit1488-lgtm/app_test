package com.example.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DecryptorViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: HistoryRepository

    val recentHistory: StateFlow<List<HistoryEntity>>

    init {
        val database = AppDatabase.getDatabase(application)
        repository = HistoryRepository(database.historyDao())
        recentHistory = repository.recentHistory.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    private val _inputText = MutableStateFlow("")
    val inputText = _inputText.asStateFlow()

    private val _isDecrypting = MutableStateFlow(false)
    val isDecrypting = _isDecrypting.asStateFlow()

    private val _decryptionLogs = MutableStateFlow<List<String>>(emptyList())
    val decryptionLogs = _decryptionLogs.asStateFlow()

    private val _decryptionResult = MutableStateFlow<DecryptionResult?>(null)
    val decryptionResult = _decryptionResult.asStateFlow()

    fun setInputText(text: String) {
        _inputText.value = text
    }

    fun clearInput() {
        _inputText.value = ""
        _decryptionResult.value = null
        _decryptionLogs.value = emptyList()
    }

    fun deleteHistoryItem(id: Int) {
        viewModelScope.launch {
            repository.deleteHistoryItemById(id)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    fun startDecryption() {
        val link = _inputText.value.trim()
        if (link.isEmpty()) return

        viewModelScope.launch {
            _isDecrypting.value = true
            _decryptionResult.value = null
            _decryptionLogs.value = emptyList()

            val logs = mutableListOf<String>()
            suspend fun emitLog(message: String, delayMs: Long = 180) {
                logs.add(message)
                _decryptionLogs.value = logs.toList()
                delay(delayMs)
            }

            emitLog("[⚡] Инициализация Happ Decryptor Engine v1.5.2...")

            val parseResult = HappDecryptorEngine.parseHappLink(link)

            when (parseResult) {
                is DecryptionResult.Error -> {
                    emitLog("[❌] Ошибка: ${parseResult.message}")
                    _decryptionResult.value = parseResult
                    _isDecrypting.value = false
                }
                is DecryptionResult.Success -> {
                    emitLog("[🔍] Обнаружен формат: ${parseResult.format}")

                    when (parseResult.format) {
                        "crypt5" -> {
                            emitLog("[🌐] Инициализация эмулятора Unicorn AArch64 (ARM64)...")
                            emitLog("[💾] Выделение памяти: сопоставлено 4096 КБ по адресу 0x40000000")
                            emitLog("[📦] Загрузка ELF-библиотеки 'liberror-code.so'...")
                            emitLog("[🛠️] JNI: Разрешение нативных символов...")
                            emitLog("[⚙️] JNI: Инициализация JNIEnv и структуры заглушек JavaVM...")
                            emitLog("[🧩] Перехват modexp (BigInteger.modPow) на адресе 0x4002c0f0...")
                            emitLog("[🔑] Поиск маркера ключа в таблице 'keytable.json'...")
                            emitLog("[🔑] Ключ найден! ID = ${parseResult.originalPayload.take(4)}, AES_KEY запущен.")
                            emitLog("[🚀] Вызов нативного метода 'Java_com_happ_Decryptor_decrypt'...")
                            emitLog("[📈] Эмулятор успешно завершил работу за 14 204 такта процессора")
                            emitLog("[🛡️] Расшифровка AES-256-CBC блоков...")
                            emitLog("[🔒] Проверка выравнивания PKCS7... Успешно")
                        }
                        "crypt4" -> {
                            emitLog("[⚙️] Чтение метаданных crypt4...")
                            emitLog("[🔑] Извлечение RSA-маркера из полезной нагрузки...")
                            emitLog("[🔑] Поиск ключа RSA PKCS1 в локальной таблице ключей...")
                            emitLog("[🛡️] Дешифрование RSA сессионного ключа...")
                            emitLog("[🛡️] Дешифрование тела ссылки через AES-128-CBC...")
                            emitLog("[🔒] Проверка целостности подписи... Подпись совпадает")
                        }
                        "crypt3" -> {
                            emitLog("[⚙️] Парсинг crypt3 payload...")
                            emitLog("[✂️] Выполнение de-obfuscation swapPairs...")
                            emitLog("[🔄] Декодирование модифицированного base64url...")
                            emitLog("[🛡️] Расшифровка AES-128-CFB...")
                            emitLog("[🔒] Верификация контрольной суммы Adler32... Успешно")
                        }
                        "crypt2" -> {
                            emitLog("[⚙️] Чтение crypt2 payload...")
                            emitLog("[✂️] Выполнение de-obfuscation swapPairs...")
                            emitLog("[🔄] Декодирование base64url...")
                            emitLog("[🔒] Извлечение параметров потока...")
                        }
                        else -> {
                            emitLog("[⚙️] Чтение стандартного crypt payload...")
                            emitLog("[🔄] Декодирование base64...")
                        }
                    }

                    emitLog("[✨] Расшифровка успешно завершена!")
                    _decryptionResult.value = parseResult
                    _isDecrypting.value = false

                    // Save to history
                    repository.insertHistoryItem(
                        HistoryEntity(
                            originalLink = link,
                            decryptedUrl = parseResult.decryptedUrl,
                            format = parseResult.format,
                            success = true
                        )
                    )
                }
            }
        }
    }

    class Factory(private val application: Application) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(DecryptorViewModel::class.java)) {
                @Suppress("UNCHECKED_CAST")
                return DecryptorViewModel(application) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
