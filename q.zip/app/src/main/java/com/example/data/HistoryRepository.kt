package com.example.data

import kotlinx.coroutines.flow.Flow

class HistoryRepository(private val historyDao: HistoryDao) {
    val recentHistory: Flow<List<HistoryEntity>> = historyDao.getRecentHistory()

    suspend fun insertHistoryItem(item: HistoryEntity) {
        historyDao.insertHistoryItem(item)
    }

    suspend fun deleteHistoryItemById(id: Int) {
        historyDao.deleteHistoryItemById(id)
    }

    suspend fun clearHistory() {
        historyDao.clearHistory()
    }
}
