package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SlateDark = Color(0xFF0F111A)
val CardDark = Color(0xFF161925)
val NeonPrimary = Color(0xFF00E6B8)
val ElectricBlue = Color(0xFF2E7BFF)
val TerminalGreen = Color(0xFF39FF14)
val DarkGrey = Color(0xFF222533)

val TextPrimary = Color(0xFFF0F4FC)
val TextSecondary = Color(0xFF909BB0)
val TextGreen = Color(0xFF8CE3A0)

val ErrorRed = Color(0xFFFF5252)
val SuccessGreen = Color(0xFF00E676)
