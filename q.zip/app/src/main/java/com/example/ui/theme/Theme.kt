package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = NeonPrimary,
    secondary = ElectricBlue,
    tertiary = TerminalGreen,
    background = SlateDark,
    surface = CardDark,
    onPrimary = SlateDark,
    onSecondary = TextPrimary,
    onTertiary = SlateDark,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    surfaceVariant = DarkGrey,
    onSurfaceVariant = TextSecondary,
    error = ErrorRed
)

private val LightColorScheme = lightColorScheme(
    primary = NeonPrimary,
    secondary = ElectricBlue,
    tertiary = TerminalGreen,
    background = SlateDark,
    surface = CardDark,
    onPrimary = SlateDark,
    onSecondary = TextPrimary,
    onTertiary = SlateDark,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    surfaceVariant = DarkGrey,
    onSurfaceVariant = TextSecondary,
    error = ErrorRed
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Disable dynamic colors to enforce our sleek cyber slate brand
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else DarkColorScheme // Enforce our premium dark theme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
